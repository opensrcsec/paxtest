#include <stdio.h>

static char msg[] = "hello world\n";

int main()
{
  printf("%s", msg);
  return 0;
}