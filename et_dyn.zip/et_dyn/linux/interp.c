const char __invoke_dynamic_linker__[] __attribute__ ((section (".interp"))) = "/lib/ld-linux.so.2";
